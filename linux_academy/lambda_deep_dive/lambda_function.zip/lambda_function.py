

def lambda_handler(event, context):
    """
    :param event:
    :param context:
    :return:
    """
    print(event)
    print("*"*20)
    print(context)
    return
